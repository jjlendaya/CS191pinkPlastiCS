import java.io.*;
import java.util.*;

public class DAOTester {
	
	public DAOTester() {

	}

	public static void main( String[] args ) {
		DataAccessObject dao = new DataAccessObject();
		String filename = "data.txt";
		ArrayList<SimulationRecord> data = dao.readFile(filename);

		for( int x=0; x<data.size(); x++ ) {
			System.out.println( data.get(x).name );
			System.out.println( "" + data.get(x).frequency );
			data.get(x).increment();
		}

		dao.writeFile("data.txt", data);
	}
}