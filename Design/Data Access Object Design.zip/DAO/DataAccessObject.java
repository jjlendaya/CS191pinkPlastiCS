import java.io.*;
import java.util.*;

public class DataAccessObject {

	public DataAccessObject() {

	}

	public ArrayList<SimulationRecord> readFile(String filename) {
		ArrayList<SimulationRecord> output = new ArrayList<SimulationRecord>();
		Scanner sc = null;

		try { 
			sc = new Scanner( new BufferedReader( new FileReader( filename ) ) );
			
			while( sc.hasNextLine() ) {
				String name = sc.nextLine();
				int freq = Integer.parseInt(sc.nextLine());
				output.add( new SimulationRecord(name, freq) );
			}

		} catch ( FileNotFoundException e ) {
			System.out.println("File Not Found!");
		}

		sc.close();
		return output;
	}

	public void writeFile(String filename, ArrayList<SimulationRecord> data) {
		PrintWriter pw = null;

		try {
			pw = new PrintWriter( new FileWriter( new File(filename) ) );

			for( int x=0; x<data.size(); x++ ) {
				pw.println(data.get(x).name);
				pw.println(data.get(x).frequency);
			}
		} catch(IOException e){
			System.out.println("IOException occured!");
		}

		pw.close();
	}
}