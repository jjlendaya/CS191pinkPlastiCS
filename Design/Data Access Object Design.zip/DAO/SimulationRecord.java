
public class SimulationRecord {
	public String name = null;
	public int frequency = 0;

	public SimulationRecord( String name, int frequency ) {
		this.name = name;
		this.frequency = frequency;
	}

	public void increment() {
		frequency = frequency + 1;
	}
}