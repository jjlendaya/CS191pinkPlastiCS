/** Automatically generated file. DO NOT MODIFY */
package com.pinkplastics.treesim;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}