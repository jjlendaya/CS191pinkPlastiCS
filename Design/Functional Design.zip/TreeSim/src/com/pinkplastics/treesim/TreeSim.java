package com.pinkplastics.treesim;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ViewFlipper;
import android.widget.ImageView;
import android.view.View;
import android.view.ViewGroup;
import android.view.GestureDetector.OnGestureListener;
import android.view.GestureDetector;

public class TreeSim extends Activity
{
    /** Called when the activity is first created. */
    private ViewFlipper viewFlipper;
    private float lastX;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.main);
         viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipper1);

         ImageView mcgi = (ImageView) findViewById(R.id.imageView1);
         ImageView mcgv = (ImageView) findViewById(R.id.imageView2);
         ImageView usage = (ImageView) findViewById(R.id.imageView3);
         ImageView uc = (ImageView) findViewById(R.id.underconstruction_image);


         /*
         mcgi.setOnClickListener(new View.OnClickListener() {
         	@Override
         	public void onClick(View v) {
         		setContentView(R.layout.underconstruction);
         	}
         });

         mcgv.setOnClickListener(new View.OnClickListener() {
         	@Override
         	public void onClick(View v) {
         		setContentView(R.layout.underconstruction);
         	}
         });
         

         usage.setOnClickListener(new View.OnClickListener() {
         	@Override
         	public void onClick(View v) {
         		setContentView(R.layout.underconstruction);
         	}
         });
         
         
         uc.setOnClickListener(new View.OnClickListener() {
         	@Override
         	public void onClick(View v) {
         		setContentView(R.layout.main);
         	}
         });*/
    }
                
    // Method to handle touch event like left to right swap and right to left swap
    public boolean onTouchEvent(MotionEvent touchevent) 
    {
         switch (touchevent.getAction())
         {
            // when user first touches the screen to swap
             case MotionEvent.ACTION_DOWN: 
             {
                 lastX = touchevent.getX();
                 break;
            }
             case MotionEvent.ACTION_UP: 
             {
                 float currentX = touchevent.getX();
                 
                 // if left to right swipe on screen
                 if (lastX < currentX) 
                 {
                      // If no more View/Child to flip
                     if (viewFlipper.getDisplayedChild() == 0)
                         break;
                     
                     // set the required Animation type to ViewFlipper
                     // The Next screen will come in form Left and current Screen will go OUT from Right 
                     viewFlipper.setInAnimation(this, R.anim.in_from_left);
                     viewFlipper.setOutAnimation(this, R.anim.out_to_right);
                     // Show the next Screen
                     viewFlipper.showNext();
                 }
                 
                 // if right to left swipe on screen
                 if (lastX > currentX)
                 {
                     if (viewFlipper.getDisplayedChild() == 1)
                         break;
                     // set the required Animation type to ViewFlipper
                     // The Next screen will come in form Right and current Screen will go OUT from Left 
                     viewFlipper.setInAnimation(this, R.anim.in_from_right);
                     viewFlipper.setOutAnimation(this, R.anim.out_to_left);
                     // Show The Previous Screen
                     viewFlipper.showPrevious();
                 }

                 if (lastX == currentX) {
                 	setContentView(R.layout.underconstruction);
                 }
                 break;
             }
         }
         return false;
    }
}
